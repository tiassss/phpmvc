-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Sep 2022 pada 15.06
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpmvc`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `mata_pelajaran` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id`, `nama`, `mata_pelajaran`) VALUES
(4, 'Ervi Rahmawati, S.T', 'Rekayasa Perangkat Lunak'),
(5, 'Wahyu Tri Wulansari, S.Pd', 'Rekayasa Perangkat Lunak'),
(6, 'Estri Handayani, S.Pd', 'Rekayasa Perangkat Lunak'),
(7, 'Fikrotu Dwi, S.Pd', 'Rekayasa Perangkat Lunak'),
(8, 'Novi Dyah Puspitasari, S.Pd', 'Rekayasa Perangkat Lunak'),
(9, 'Ivans Zuwanta, S.Kom', 'Rekayasa Perangkat Lunak'),
(10, 'Safira Maya Shofie, S.Pd', 'Rekayasa Perangkat Lunak'),
(11, 'Labib Fayumi', 'Rekayasa Perangkat Lunak');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nama`, `jenis_kelamin`, `alamat`) VALUES
(26, 'MUHAMMAD FAIZ', 'lakilaki', 'Trenggalek,Jawa Timur'),
(27, 'MUHAMMAD IQBAL ROMADLON', 'lakilaki', 'Trenggalek,Jawa Timur'),
(28, 'MUHAMMAD RIZKY', 'lakilaki', 'Trenggalek,Jawa Timur'),
(29, 'MUHAMMAD WAHYU FAJRI APRILIO', 'lakilaki', 'Trenggalek,Jawa Timur'),
(30, 'MUHAMMAD YUSUF ALFIANSYAH', 'lakilaki', 'Trenggalek,Jawa Timur'),
(31, 'MUHAMMMAD ZAITUN ROHMAT SANJAYA', 'lakilaki', 'Trenggalek,Jawa Timur'),
(32, 'NA\'AFIS IZA MAULANA LIFKRI', 'lakilaki', 'Trenggalek,Jawa Timur'),
(33, 'MUHAMMAD YUDHA PRASETYA', 'lakilaki', 'Trenggalek,Jawa Timur');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `guru`
--
ALTER TABLE `guru`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
