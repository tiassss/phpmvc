<html>

<body>
    <script src="<?= BASE_URL; ?>/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_URL; ?>/js/bootstrap.script.js"></script>

</body>

</html>