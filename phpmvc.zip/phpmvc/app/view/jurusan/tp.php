<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>Teknik Pengelasan SMKN 2 TRENGGALEK</h3>
            <br>
            <p>
                <img src="<?= BASE_URL; ?>/img/tp.png" width="300" height="275" alt="" style="float:left; margin:0 20px 4px 0;" />
                Teknik Pengelasan merupakan salah satu jurusan yang berada di bidang Teknik Mesin.Lulusan dari Teknik Pengelasan memiliki peran penting dalam dunia industri.Sebab semua konstruksi bangunan apapun pasti berkaitan dengan pengeasan.
                <p>Kesempatan Kerja : 
                    <br> - Pabrik
                    <br> - Wiraswata
                    <br> - PUPR
                </p>
        </div>

    </div>
</body>

</html>