<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>Teknik Konstruksi dan Perumahan SMKN 2 TRENGGALEK</h3>
            <br>
            <p>
                <img src="<?= BASE_URL; ?>/img/tkp.jpeg" width="300" height="275" alt="" style="float:left; margin:0 20px 4px 0;" />
                KGSP / TKP akan belajar membangun sebuah bangunan,sanitasi dan kegiatan untuk merawatnya.Program belajar KGSP ini,diikuti oleh peserta didik selma 4 Tahun setara dengan kuliah D1.
                <p>Kesempatan Kerja : 
                    <br> - Konsultan
                    <br> - Perusahaaan Konstruksi
                    <br> - PUPR
                </p>
            </p>
        </div>

    </div>
</body>

</html>