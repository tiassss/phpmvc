<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>Rekayasa Perangkat Lunak SMKN 2 TRENGGALEK</h3>
            <br>
            <p>
                <img src="img/rpl.jpg" width="300" height="275" alt="" style="float:left; margin:0 20px 4px 0;" />
                Rekayasa Perangkat Lunak atau biasa disingkat dengan RPL adalah sebuah jurusan yang mendalami dan mempelajari semua cara cara pengembangan perangkat lunak berkaitan dengan software komputer mulai dari pembuatan website,aplikasi,game dan semua yang berkaitan dengan pemrograman dengan menguasai bahasa pemrograman tersebut.
            <p>Kesempatan Kerja :
                <br> - Software House
                <br> - Perusahaan Teknologi
                <br> - Semua Kantor Pemerintahan
            </p>
            </p>
        </div>

    </div>
</body>

</html>