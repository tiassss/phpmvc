<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>Teknik Pendingin Tata Udara dan Pemanasan SMKN 2 TRENGGALEK</h3>
            <br>
            <p>
                <img src="<?= BASE_URL; ?>/img/tptup.jpg" width="300" height="275" alt="" style="float:left; margin:0 20px 4px 0;" />
                TPTUP adalah dua disiplin ilmu yang saling terkait serta berhubungan dengan sejumlah disiplin ilmu yang lainnya,seperti Teknik Mesin,Teknik Listrik,Teknik Sipil & Arsitektur,Teknologi Makanan & Kesehatan,Teknik Fisika,Teknik Kimia.
                <p>Kesempatan Kerja : 
                    <br> - Perusahaan dan Pabrik, Semua Kantor Pemerintahan
                    <br> - Hotel
                    <br> - Wirausaha
                </p>


            </p>
        </div>

    </div>
</body>

</html>