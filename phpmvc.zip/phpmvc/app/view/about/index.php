<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
    <link rel="stylesheet" href="http://localhost/phpmvc/public/css/bootstrap.css">
</head>

<body>
    <div class="container">
        <div class="jumbotron mt-4">
            <h3>About</h3>
            <br>
            <p>
                <img src="img/i.jfif" width="300" height="350" alt="kepsek" style="float:left; margin:0 20px 4px 0;" />
                <Br>Halaman Ini dibuat oleh Sih Ageng Heru Cahyoningtias
                <br>
                <br>Nama saya adalah Sih Ageng Heru Cahyoningtias
                <br> di Trenggalek,Pada tanggal 09 Desember 2004
                <br>Alamat rumah saya berada di Ds.Jombok Kecamatan Pule Trenggalek
                <br>Umur saya sekarang adalah 17 Tahun
                <br>Saya bersekolah di SMK Negeri 2 Trenggalek
                <br>Saya mengambil Jurusan RPL (Rekayasa Perangkat Lunak)
        </div>
    </div>